import tempfile
import subprocess
from undo_cli.utils import run_cmd, commands, git_repo_required

"""
Supported Git Commands: https://git-scm.com/docs
"""


"""
Pre-req: Has to be in the same repo as the user
Internal git state machine using a temp dir to do simulations for Large Language Models to do retries 
"""


class GitSim:
    def __init__(self):
        self._log = None

    @property
    def log(self):
        if self._log is None:
            self._fetch_log()
        return self._log

    @git_repo_required
    def _fetch_log(self):
        stdout, stderr = run_cmd(commands["log"])
        if stdout:
            self._log = stdout.decode("utf-8")
        else:
            self._log = "Error fetching logs" if stderr else "No logs available"

    @git_repo_required
    def sim(self):
        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                # Get the current repo path
                repo_url_stdout, _ = run_cmd(commands["repository_url"])
                print(repo_url_stdout)

                pass

        except Exception as e:
            raise Exception(f"Error creating temp dir: {e}")


if __name__ == "__main__":
    git = GitSim()
    git.sim()
