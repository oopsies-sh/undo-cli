# Oopsies CLI

A simple CLI tool that prints "Hello, World!".

## Installation

You can install the CLI tool using pip:

```sh
pip install .